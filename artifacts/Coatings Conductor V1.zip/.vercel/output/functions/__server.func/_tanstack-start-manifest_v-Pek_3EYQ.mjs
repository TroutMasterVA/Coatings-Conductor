//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Pek_3EYQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CHN3PYme.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CHN3PYme.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-WKkODkAu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
