import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forecast-BSzTkCi-.js
function zoned(iso, timeZone) {
	const naive = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2})(?::(\d{2}))?(?!.*(?:Z|[+-]\d{2}:\d{2}))/);
	if (naive) {
		Number(naive[1]);
		const month = Number(naive[2]);
		const day = Number(naive[3]);
		return {
			hour: Number(naive[4]),
			weekday: (/* @__PURE__ */ new Date(`${naive[1]}-${naive[2]}-${naive[3]}T12:00:00Z`)).toLocaleDateString("en-US", {
				weekday: "short",
				timeZone: "UTC"
			}),
			dateLabel: `${month}/${day}`,
			dateKey: `${naive[1]}-${naive[2]}-${naive[3]}`
		};
	}
	const d = new Date(iso);
	const fmt = new Intl.DateTimeFormat("en-US", {
		timeZone,
		weekday: "short",
		hour: "2-digit",
		hourCycle: "h23",
		month: "numeric",
		day: "numeric",
		year: "numeric"
	});
	const map = {};
	for (const p of fmt.formatToParts(d)) if (p.type !== "literal") map[p.type] = p.value;
	const hour = Number(map.hour);
	const month = Number(map.month);
	const day = Number(map.day);
	const year = Number(map.year);
	return {
		hour: Number.isFinite(hour) ? hour : d.getHours(),
		weekday: map.weekday ?? "",
		dateLabel: `${month}/${day}`,
		dateKey: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`
	};
}
function hasNumericWindow(env) {
	return env.ambientTempMinF != null || env.ambientTempMaxF != null || env.substrateTempMinF != null || env.substrateTempMaxF != null || env.relativeHumidityMax != null || env.dewPointSpreadMinF != null || env.windMaxMph != null || env.precipitationAllowed === false;
}
function wetForecast(text) {
	return /\b(rain|shower|storm|thunder|snow|sleet|drizzle|precip)/i.test(text);
}
function scoreHour(raw, env, timeZone = "UTC") {
	const z = zoned(raw.startIso, timeZone);
	const reasons = [];
	let hard = 0;
	let soft = 0;
	const temp = raw.tempF;
	const minT = env.ambientTempMinF ?? env.substrateTempMinF;
	const maxT = env.ambientTempMaxF ?? env.substrateTempMaxF;
	if (temp != null && minT != null) {
		if (temp < minT) {
			reasons.push(`Air ${temp}°F below min ${minT}°F`);
			hard += 1;
		} else if (temp < minT + 5) {
			reasons.push(`Air ${temp}°F within 5° of min`);
			soft += 1;
		}
	}
	if (temp != null && maxT != null) {
		if (temp > maxT) {
			reasons.push(`Air ${temp}°F above max ${maxT}°F`);
			hard += 1;
		} else if (temp > maxT - 5) {
			reasons.push(`Air ${temp}°F within 5° of max`);
			soft += 1;
		}
	}
	if (raw.rh != null && env.relativeHumidityMax != null) {
		if (raw.rh > env.relativeHumidityMax) {
			reasons.push(`RH ${raw.rh}% above max ${env.relativeHumidityMax}%`);
			hard += 1;
		} else if (raw.rh > env.relativeHumidityMax - 5) {
			reasons.push(`RH ${raw.rh}% near max`);
			soft += 1;
		}
	}
	const spread = temp != null && raw.dewpointF != null ? Math.round((temp - raw.dewpointF) * 10) / 10 : null;
	if (spread != null && env.dewPointSpreadMinF != null) {
		if (spread < env.dewPointSpreadMinF) {
			reasons.push(`Dew spread ${spread}°F < ${env.dewPointSpreadMinF}°F`);
			hard += 1;
		} else if (spread < env.dewPointSpreadMinF + 2) {
			reasons.push(`Dew spread ${spread}°F is thin`);
			soft += 1;
		}
	}
	if (env.precipitationAllowed === false) {
		if (raw.pop != null && raw.pop >= 40 || raw.precipIn != null && raw.precipIn > .02 || wetForecast(raw.shortForecast)) {
			reasons.push(raw.pop != null ? `Precip ${raw.pop}% · ${raw.shortForecast || "wet"}` : raw.shortForecast || "Precipitation risk");
			hard += 1;
		} else if (raw.pop != null && raw.pop >= 20) {
			reasons.push(`Precip ${raw.pop}%`);
			soft += 1;
		}
	}
	if (raw.windMph != null && env.windMaxMph != null) {
		if (raw.windMph > env.windMaxMph) {
			reasons.push(`Wind ${raw.windMph} mph > ${env.windMaxMph}`);
			hard += 1;
		} else if (raw.windMph > env.windMaxMph - 5) {
			reasons.push(`Wind ${raw.windMph} mph near limit`);
			soft += 1;
		}
	}
	let status = "go";
	if (!hasNumericWindow(env)) status = "unknown";
	else if (hard > 0) status = "nogo";
	else if (soft > 0) status = "caution";
	if (status === "go" && reasons.length === 0) reasons.push("Inside PDS window");
	return {
		startIso: raw.startIso,
		hour: z.hour,
		weekday: z.weekday,
		dateLabel: z.dateLabel,
		status,
		reasons,
		tempF: raw.tempF,
		rh: raw.rh,
		dewpointF: raw.dewpointF,
		spreadF: spread,
		pop: raw.pop,
		precipIn: raw.precipIn,
		windMph: raw.windMph,
		shortForecast: raw.shortForecast,
		dateKey: z.dateKey
	};
}
function bestRange(hours) {
	if (hours.length === 0) return null;
	const preferGo = hours.some((h) => h.status === "go");
	const ok = (h) => preferGo ? h.status === "go" : h.status === "go" || h.status === "caution";
	let bestStart = -1;
	let bestLen = 0;
	let i = 0;
	while (i < hours.length) {
		if (!ok(hours[i])) {
			i += 1;
			continue;
		}
		let j = i;
		while (j < hours.length && ok(hours[j])) j += 1;
		const len = j - i;
		if (len > bestLen) {
			bestLen = len;
			bestStart = i;
		}
		i = j;
	}
	if (bestStart < 0) return null;
	if (bestLen >= 18) return "All day";
	const a = hours[bestStart];
	const b = hours[bestStart + bestLen - 1];
	const fmt = (h) => `${String(h).padStart(2, "0")}:00`;
	let endHour = b.hour + 1;
	if (endHour >= 24) endHour = 24;
	return `${fmt(a.hour)}–${fmt(endHour)}`;
}
function bundleDays(hours, meta, env) {
	const byDate = /* @__PURE__ */ new Map();
	for (const h of hours) {
		const key = h.dateKey || h.startIso.slice(0, 10);
		const list = byDate.get(key) ?? [];
		list.push(h);
		byDate.set(key, list);
	}
	const days = [];
	for (const [date, list] of byDate) {
		const goHours = list.filter((h) => h.status === "go").length;
		const cautionHours = list.filter((h) => h.status === "caution").length;
		const nogoHours = list.filter((h) => h.status === "nogo").length;
		let status = "unknown";
		if (goHours >= 3) status = "go";
		else if (goHours > 0 || cautionHours >= 4) status = "caution";
		else if (list.some((h) => h.status !== "unknown")) status = "nogo";
		const reasonCount = /* @__PURE__ */ new Map();
		for (const h of list) if (h.status === "nogo" || h.status === "caution") {
			const key = h.reasons[0] ?? "";
			if (key) reasonCount.set(key, (reasonCount.get(key) ?? 0) + 1);
		}
		const limiting = [...reasonCount.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k]) => k);
		days.push({
			date,
			weekday: list[0]?.weekday ?? "",
			dateLabel: list[0]?.dateLabel ?? date,
			status,
			goHours,
			cautionHours,
			nogoHours,
			bestRange: bestRange(list),
			limiting,
			hours: list
		});
	}
	days.sort((a, b) => a.date.localeCompare(b.date));
	const scored = hasNumericWindow(env);
	const best = [...days].filter((d) => d.status === "go").sort((a, b) => b.goHours - a.goHours)[0];
	const alt = [...days].filter((d) => d.bestRange).sort((a, b) => b.goHours + b.cautionHours - (a.goHours + a.cautionHours))[0];
	let headline = "Forecast loaded — PDS has no numeric application window to score against.";
	if (scored && best?.bestRange) headline = `Best window: ${best.weekday} ${best.dateLabel}  ${best.bestRange}  (${best.goHours} go hours)`;
	else if (scored && alt?.bestRange) headline = `No clean go-day. Least-bad: ${alt.weekday} ${alt.dateLabel}  ${alt.bestRange}`;
	else if (scored) headline = "No in-window hours in this forecast. Hold the product.";
	return {
		...meta,
		days,
		headline
	};
}
var UA = "FieldCard/1.0 (field-qc reference; nws-weather-windows)";
function cToF(c) {
	return Math.round(c * 9 / 5 + 32);
}
function parseWind(v) {
	if (typeof v === "number" && Number.isFinite(v)) return v;
	if (typeof v !== "string") return null;
	const nums = [...v.matchAll(/(\d+(?:\.\d+)?)/g)].map((m) => Number(m[1]));
	if (!nums.length) return null;
	return Math.max(...nums);
}
async function geocodeZip(zip) {
	const res = await fetch(`https://api.zippopotam.us/us/${zip}`);
	if (!res.ok) throw new Error("ZIP not found. Use a 5-digit US ZIP.");
	const body = await res.json();
	const place = body.places?.[0];
	if (!place) throw new Error("ZIP not found.");
	return {
		zip: body["post code"] ?? zip,
		city: place["place name"],
		state: place["state abbreviation"] || place.state,
		lat: Number(place.latitude),
		lon: Number(place.longitude)
	};
}
async function nwsHourly(lat, lon) {
	const points = await fetch(`https://api.weather.gov/points/${lat.toFixed(4)},${lon.toFixed(4)}`, { headers: {
		"User-Agent": UA,
		Accept: "application/geo+json"
	} });
	if (!points.ok) return null;
	const pt = await points.json();
	const hourlyUrl = pt.properties?.forecastHourly;
	if (!hourlyUrl) return null;
	const hourly = await fetch(hourlyUrl, { headers: {
		"User-Agent": UA,
		Accept: "application/geo+json"
	} });
	if (!hourly.ok) return null;
	return {
		hours: ((await hourly.json()).properties?.periods ?? []).slice(0, 168).map((p) => {
			let tempF = p.temperature;
			if (p.temperatureUnit === "C") tempF = cToF(p.temperature);
			let dewpointF = null;
			if (p.dewpoint?.value != null) dewpointF = /degC/i.test(p.dewpoint.unitCode ?? "") ? cToF(p.dewpoint.value) : p.dewpoint.value;
			return {
				startIso: p.startTime,
				tempF,
				rh: p.relativeHumidity?.value ?? null,
				dewpointF,
				pop: p.probabilityOfPrecipitation?.value ?? null,
				precipIn: null,
				windMph: parseWind(p.windSpeed),
				shortForecast: p.shortForecast ?? ""
			};
		}),
		source: "NOAA National Weather Service hourly",
		timezone: pt.properties?.timeZone ?? "local"
	};
}
async function openMeteo(lat, lon) {
	const url = new URL("https://api.open-meteo.com/v1/forecast");
	url.searchParams.set("latitude", String(lat));
	url.searchParams.set("longitude", String(lon));
	url.searchParams.set("hourly", "temperature_2m,relative_humidity_2m,dew_point_2m,precipitation_probability,precipitation,wind_speed_10m,weather_code");
	url.searchParams.set("temperature_unit", "fahrenheit");
	url.searchParams.set("wind_speed_unit", "mph");
	url.searchParams.set("precipitation_unit", "inch");
	url.searchParams.set("timezone", "auto");
	url.searchParams.set("forecast_days", "7");
	const res = await fetch(url.toString());
	if (!res.ok) throw new Error("Weather forecast is unavailable.");
	const body = await res.json();
	const h = body.hourly;
	if (!h?.time?.length) throw new Error("Hourly forecast was empty.");
	const wx = (code) => {
		if (code == null) return "";
		if (code >= 95) return "Thunderstorm";
		if (code >= 80) return "Showers";
		if (code >= 71) return "Snow";
		if (code >= 61) return "Rain";
		if (code >= 51) return "Drizzle";
		if (code >= 45) return "Fog";
		if (code >= 1) return "Clouds";
		return "Clear";
	};
	return {
		hours: h.time.map((time, i) => ({
			startIso: time.length === 16 ? `${time}:00` : time,
			tempF: h.temperature_2m[i] ?? null,
			rh: h.relative_humidity_2m[i] ?? null,
			dewpointF: h.dew_point_2m[i] ?? null,
			pop: h.precipitation_probability[i] ?? null,
			precipIn: h.precipitation[i] ?? null,
			windMph: h.wind_speed_10m[i] ?? null,
			shortForecast: wx(h.weather_code[i] ?? null)
		})),
		source: "NOAA models via Open-Meteo (NWS hourly unavailable)",
		timezone: body.timezone ?? "auto"
	};
}
var loadForecast_createServerFn_handler = createServerRpc({
	id: "dd0ffdd043195dddbd4cbc41ec11e49f69e12dfaf5d4c9ae5ca40747acb4b9d9",
	name: "loadForecast",
	filename: "src/lib/forecast.ts"
}, (opts) => loadForecast.__executeServer(opts));
var loadForecast = createServerFn({ method: "POST" }).validator((input) => {
	const zip = (input?.zip ?? "").replace(/\D/g, "").slice(0, 5);
	if (zip.length !== 5) throw new Error("Enter a 5-digit US ZIP.");
	return {
		zip,
		environmentals: input.environmentals
	};
}).handler(loadForecast_createServerFn_handler, async ({ data }) => {
	try {
		const geo = await geocodeZip(data.zip);
		let pack = await nwsHourly(geo.lat, geo.lon).catch(() => null);
		if (!pack || pack.hours.length < 12) pack = await openMeteo(geo.lat, geo.lon);
		return {
			ok: true,
			forecast: bundleDays(pack.hours.map((h) => scoreHour(h, data.environmentals, pack.timezone)), {
				zip: geo.zip,
				city: geo.city,
				state: geo.state,
				lat: geo.lat,
				lon: geo.lon,
				timezone: pack.timezone,
				source: pack.source,
				issuedAt: (/* @__PURE__ */ new Date()).toISOString()
			}, data.environmentals)
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Forecast failed"
		};
	}
});
//#endregion
export { loadForecast_createServerFn_handler };
