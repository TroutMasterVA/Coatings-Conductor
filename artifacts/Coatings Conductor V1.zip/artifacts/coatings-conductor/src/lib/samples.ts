import type { FieldCardData } from "./types";

function stamp(partial: Omit<FieldCardData, "id">): FieldCardData {
  return { id: crypto.randomUUID(), ...partial };
}

export const SAMPLES: { key: string; label: string; blurb: string; card: FieldCardData }[] = [
  {
    key: "macropoxy",
    label: "Macropoxy 646 Fast Cure",
    blurb: "Polyamide epoxy · structural steel",
    card: stamp({
      product: {
        name: "Macropoxy 646 Fast Cure",
        manufacturer: "Sherwin-Williams Protective & Marine",
        productType: "Polyamide epoxy, two-component",
        mixRatio: "1:1 by volume",
        revision: "Illustrative field extract",
      },
      storage: {
        temperatureRange: "40°F–100°F",
        conditions: ["Indoors", "Tightly closed", "Protect from freezing and direct sun", "FIFO"],
      },
      shelfLife: { unopened: "24 months at 77°F", mixedPotLife: "~2 hours at 77°F" },
      credentials: {
        required: ["Two-component epoxy trained applicators", "NACE/AMPP CIP or SSPC PCI for critical hold points"],
      },
      surfacePrep: {
        substrates: ["Carbon steel", "Sound existing coating"],
        methods: ["SSPC-SP6 / NACE No. 3 commercial blast", "SSPC-SP10 for immersion"],
        profile: "1.5–3.0 mils",
        cleanliness: "Dry, dust-free, no chloride contamination",
      },
      environmentals: {
        ambientTempMinF: 35,
        ambientTempMaxF: 120,
        substrateTempMinF: 35,
        substrateTempMaxF: 120,
        relativeHumidityMax: null,
        dewPointSpreadMinF: 5,
        precipitationAllowed: false,
        windMaxMph: 25,
        notes: "Surface ≥5°F above dew point. Do not apply if rain imminent before water-resistant.",
      },
      mixing: { ratio: "1:1 by volume", potLife: "~2 h at 77°F", inductionTime: "None (Fast Cure)" },
      installation: {
        methods: ["Airless spray", "Brush", "Roller"],
        filmThickness: "5–10 mils DFT per coat",
        coverage: "~160–225 sq ft/gal at 5–7 mils",
      },
      holdPoints: [
        { step: 1, name: "Material receipt", criteria: "Batch, shelf life, storage temp" },
        { step: 2, name: "Surface preparation", criteria: "Standard, profile, cleanliness" },
        { step: 3, name: "Ambient log", criteria: "Air / substrate / dew point before apply" },
        { step: 4, name: "Mix check", criteria: "Start time and ratio" },
        { step: 5, name: "Stripe coat", criteria: "Welds and edges" },
        { step: 6, name: "WFT checks", criteria: "During application" },
        { step: 7, name: "DFT survey", criteria: "SSPC-PA 2 after cure" },
      ],
      inspection: { methods: ["Visual", "WFT", "DFT (SSPC-PA 2)", "Adhesion ASTM D3359/D4541", "Holiday NACE SP0188"] },
      cure: { touch: "~2 h at 77°F", recoatMin: "~3.5 h", fullCure: "7 days" },
      safety: { ppe: ["Organic vapor respirator as required", "Chemical goggles", "Gloves", "Ventilation"] },
    }),
  },
  {
    key: "sikadur",
    label: "Sikadur-31 Hi-Mod Gel",
    blurb: "Structural epoxy adhesive · moisture-tolerant",
    card: stamp({
      product: {
        name: "Sikadur-31 Hi-Mod Gel",
        manufacturer: "Sika Corporation",
        productType: "100% solids moisture-tolerant structural epoxy adhesive",
        mixRatio: "1:1 by volume",
        revision: "Illustrative field extract",
      },
      storage: { temperatureRange: "40°F–90°F", conditions: ["Dry", "Unopened", "Do not freeze", "Condition to 65–75°F before mix"] },
      shelfLife: { unopened: "24 months", mixedPotLife: "30–45 min at 73°F" },
      credentials: { required: ["Structural epoxy experience", "Engineer-approved procedure for critical work"] },
      surfacePrep: {
        substrates: ["Concrete", "Steel"],
        methods: ["SSD or dry concrete", "SSPC-SP6 minimum on steel"],
        profile: "2–3 mils on steel",
        cleanliness: "No oil, curing compound, standing water",
      },
      environmentals: {
        ambientTempMinF: 40,
        ambientTempMaxF: 95,
        substrateTempMinF: 40,
        substrateTempMaxF: 95,
        relativeHumidityMax: null,
        dewPointSpreadMinF: 5,
        precipitationAllowed: false,
        windMaxMph: null,
        notes: "Moisture-tolerant. Protect from rain until tack-free.",
      },
      mixing: { ratio: "1:1 by volume", potLife: "30–45 min at 73°F", inductionTime: "None" },
      installation: { methods: ["Trowel", "Gloved hand", "Caulk-style"], filmThickness: "Bond-line 1/32–1/8 in", coverage: "Per engineer" },
      holdPoints: [
        { step: 1, name: "Material conditioning", criteria: "Shelf life and temp" },
        { step: 2, name: "Substrate soundness", criteria: "Prep inspection" },
        { step: 3, name: "Ambient / dew point", criteria: "Before place" },
        { step: 4, name: "Mix uniformity", criteria: "No streaks" },
        { step: 5, name: "Bond-line", criteria: "Before close-up" },
      ],
      inspection: { methods: ["Visual mix", "Bond-line squeeze-out", "Sounding after cure"] },
      cure: { touch: "1–2 h at 73°F", recoatMin: "N/A", fullCure: "~3 days mechanical" },
      safety: { ppe: ["Gloves", "Eye protection", "Long sleeves", "Ventilate"] },
    }),
  },
  {
    key: "dymonic",
    label: "Dymonic 100",
    blurb: "PU joint sealant · building envelope",
    card: stamp({
      product: {
        name: "Dymonic 100",
        manufacturer: "Tremco",
        productType: "High-movement single-component moisture-cure polyurethane sealant",
        mixRatio: "Single component",
        revision: "Illustrative field extract",
      },
      storage: { temperatureRange: "40°F–110°F", conditions: ["Unopened", "Dry"] },
      shelfLife: { unopened: "12 months", mixedPotLife: "N/A — single component" },
      credentials: { required: ["Joint design training", "Manufacturer training for warranty work"] },
      surfacePrep: {
        substrates: ["Concrete", "Aluminum", "Steel", "Glass"],
        methods: ["Clean, dry, frost-free", "Backer rod", "Primer where required"],
        profile: "Per joint design",
        cleanliness: "Remove old sealant and laitance",
      },
      environmentals: {
        ambientTempMinF: 40,
        ambientTempMaxF: 120,
        substrateTempMinF: 40,
        substrateTempMaxF: 120,
        relativeHumidityMax: null,
        dewPointSpreadMinF: null,
        precipitationAllowed: false,
        windMaxMph: null,
        notes: "No condensation. High humidity accelerates skinning.",
      },
      mixing: { ratio: "Single component", potLife: "N/A", inductionTime: "N/A" },
      installation: { methods: ["Gun continuous pass", "Tool immediately"], filmThickness: "Depth ½ of width, min ¼ in", coverage: "Per joint factor" },
      holdPoints: [
        { step: 1, name: "Joint geometry", criteria: "Backer rod check" },
        { step: 2, name: "Cleanliness / primer", criteria: "Open-time" },
        { step: 3, name: "Ambient / substrate", criteria: "Temperature" },
        { step: 4, name: "Adhesion test", criteria: "Field pull as specified" },
      ],
      inspection: { methods: ["Visual continuity", "Field adhesion", "Joint factor"] },
      cure: { touch: "Skins 2–4 h at 75°F", recoatMin: "Per topcoat", fullCure: "~7 days" },
      safety: { ppe: ["Gloves", "Eye protection", "Ventilation"] },
    }),
  },
];

export const SAMPLE_TEXT: Record<string, string> = {
  macropoxy: "Macropoxy 646 Fast Cure — polyamide epoxy for structural steel. Air/surface 35–120°F. Dew spread ≥5°F. Dry only.",
  sikadur: "Sikadur-31 Hi-Mod Gel — moisture-tolerant structural epoxy. Min 40°F. Steel and concrete.",
  dymonic: "Dymonic 100 — PU joint sealant. 40–120°F. Clean dry joints. Moisture-cure.",
};
