import { inShift, mitigationById, skyFactor, solarEnvelope, substrateById } from "./mitigations";
import type {
  Calibration,
  DayWindow,
  Environmentals,
  ForecastBundle,
  HourWindow,
  MitigationId,
  RawHour,
  SubstrateId,
  WindowStatus,
} from "./types";
import { DEFAULT_CALIBRATION } from "./types";

export type SiteCtx = {
  substrate: SubstrateId;
  mitigations: MitigationId[];
  calibration?: Calibration;
  moistureTolerant?: boolean;
};

function lerp(a: number, b: number, t: number) {
  const x = Math.min(1, Math.max(0, t));
  return a + (b - a) * x;
}

function axes(cal: Calibration) {
  if (cal.linked) {
    return { solar: cal.master, thermal: cal.master, moisture: cal.master, precip: cal.master, wind: cal.master };
  }
  return cal;
}

function zoned(iso: string, timeZone: string) {
  const naive = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2})/);
  if (naive && !/[Z+-]/.test(iso.slice(10))) {
    const hour = Number(naive[4]);
    const month = Number(naive[2]);
    const day = Number(naive[3]);
    const weekday = new Date(`${naive[1]}-${naive[2]}-${naive[3]}T12:00:00Z`).toLocaleDateString("en-US", {
      weekday: "short",
      timeZone: "UTC",
    });
    return { hour, weekday, dateLabel: `${month}/${day}`, dateKey: `${naive[1]}-${naive[2]}-${naive[3]}` };
  }
  const d = new Date(iso);
  const fmt = new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "short",
    hour: "2-digit",
    hourCycle: "h23",
    month: "numeric",
    day: "numeric",
    year: "numeric",
  });
  const map: Record<string, string> = {};
  for (const p of fmt.formatToParts(d)) if (p.type !== "literal") map[p.type] = p.value;
  return {
    hour: Number(map.hour) || d.getHours(),
    weekday: map.weekday ?? "",
    dateLabel: `${map.month}/${map.day}`,
    dateKey: `${map.year}-${String(map.month).padStart(2, "0")}-${String(map.day).padStart(2, "0")}`,
  };
}

function overLimit(value: number, max: number, axis: number): "hard" | "soft" | null {
  const hardPad = lerp(10, 0, axis);
  const softStart = lerp(8, 3, axis);
  if (value > max + hardPad) return "hard";
  if (value > max - softStart) return "soft";
  return null;
}

function underLimit(value: number, min: number, axis: number): "hard" | "soft" | null {
  const hardPad = lerp(10, 0, axis);
  const softStart = lerp(8, 3, axis);
  if (value < min - hardPad) return "hard";
  if (value < min + softStart) return "soft";
  return null;
}

function round1(n: number) {
  return Math.round(n * 10) / 10;
}

export function scoreHour(raw: RawHour, env: Environmentals, timeZone: string, site: SiteCtx): HourWindow {
  const z = zoned(raw.startIso, timeZone);
  const reasons: string[] = [];
  let hard = 0;
  let soft = 0;
  const mits = site.mitigations;
  const sub = substrateById(site.substrate);
  const cal = axes(site.calibration ?? DEFAULT_CALIBRATION);
  const shiftOk = inShift(z.hour, mits);

  let air = raw.tempF;
  let rh = raw.rh;
  let dew = raw.dewpointF;
  let wind = raw.windMph;
  let precipBlocked = env.precipitationAllowed === false;
  let sun = solarEnvelope(z.hour) * skyFactor(raw.shortForecast, raw.cloudCover);
  const envelope = solarEnvelope(z.hour);

  if (mits.includes("canopy")) sun *= 0.12;
  if (mits.includes("light_tent")) {
    sun *= 0.08;
    wind = wind != null ? wind * 0.25 : wind;
    precipBlocked = false;
    if (air != null) air = round1(air + 2 * envelope);
  }
  if (mits.includes("dark_tent")) {
    sun *= 0.12;
    wind = wind != null ? wind * 0.25 : wind;
    precipBlocked = false;
    if (air != null) air = round1(air + 12 * Math.max(envelope, 0.2));
  }
  if (mits.includes("dehumidify_tent")) {
    if (!mits.includes("light_tent") && !mits.includes("dark_tent") && !mits.includes("climate_tent")) sun *= 0.1;
    precipBlocked = false;
    if (rh != null) rh = Math.max(20, rh - 18);
    if (dew != null) dew = round1(dew - 4);
  }
  if (mits.includes("climate_tent")) {
    sun = 0;
    wind = 0;
    precipBlocked = false;
    if (air != null) air = round1(air + (72 - air) * 0.65);
    if (rh != null) rh = round1(rh + (48 - rh) * 0.7);
  }
  if (mits.includes("windscreen") && wind != null) wind *= 0.4;
  if (mits.includes("heaters") && air != null && !mits.includes("climate_tent")) air = round1(air + 16);

  let solarGain = sun * sub.peakGainF * lerp(0.58, 1.18, cal.solar);
  if (z.hour >= 4 && z.hour <= 7) solarGain -= 2;
  let substrateF = air != null ? round1(air + solarGain) : null;
  if (mits.includes("preheat") && sub.metal && substrateF != null) substrateF = round1(substrateF + 14);
  if (mits.includes("heaters") && substrateF != null && !mits.includes("climate_tent")) substrateF = round1(substrateF + 10);
  let fogged = false;
  if (mits.includes("fog_mist") && substrateF != null && solarGain > 3) {
    if (sub.metal) {
      substrateF = round1(substrateF - 22);
      fogged = true;
    } else if (sub.id === "concrete") {
      substrateF = round1(substrateF - 10);
      fogged = true;
    }
  }

  const airMin = env.ambientTempMinF;
  const airMax = env.ambientTempMaxF;
  const subMin = env.substrateTempMinF ?? env.ambientTempMinF;
  const subMax = env.substrateTempMaxF ?? env.ambientTempMaxF;

  if (air != null && airMin != null) {
    const hit = underLimit(air, airMin, cal.thermal);
    if (hit === "hard") { reasons.push(`Air ${air}°F below min ${airMin}°F`); hard++; }
    else if (hit === "soft") { reasons.push(`Air ${air}°F near min`); soft++; }
  }
  if (air != null && airMax != null) {
    const hit = overLimit(air, airMax, cal.thermal);
    if (hit === "hard") { reasons.push(`Air ${air}°F above max ${airMax}°F`); hard++; }
    else if (hit === "soft") { reasons.push(`Air ${air}°F near max`); soft++; }
  }
  if (substrateF != null && subMin != null) {
    const hit = underLimit(substrateF, subMin, cal.thermal);
    if (hit === "hard") { reasons.push(`${sub.label} ${substrateF}°F below min`); hard++; }
    else if (hit === "soft") { reasons.push(`${sub.label} ${substrateF}°F near min`); soft++; }
  }
  if (substrateF != null && subMax != null) {
    const hit = overLimit(substrateF, subMax, cal.thermal);
    if (hit === "hard") {
      reasons.push(`${sub.label} ${substrateF}°F > max ${subMax}°F (air ${air ?? "—"}° + sun ${round1(Math.max(0, solarGain))}°)`);
      hard++;
    } else if (hit === "soft") {
      reasons.push(`${sub.label} ${substrateF}°F near max`);
      soft++;
    }
  }
  if (rh != null && env.relativeHumidityMax != null) {
    const hit = overLimit(rh, env.relativeHumidityMax, cal.moisture);
    if (hit === "hard") { reasons.push(`RH ${rh}% above max`); hard++; }
    else if (hit === "soft") { reasons.push(`RH ${rh}% near max`); soft++; }
  }
  const spread =
    substrateF != null && dew != null ? round1(substrateF - dew) : air != null && dew != null ? round1(air - dew) : null;
  if (spread != null && env.dewPointSpreadMinF != null) {
    const hardPad = lerp(3, 0, cal.moisture);
    if (spread < env.dewPointSpreadMinF - hardPad) { reasons.push(`Dew spread ${spread}°F < ${env.dewPointSpreadMinF}°F`); hard++; }
    else if (spread < env.dewPointSpreadMinF + 2) { reasons.push(`Dew spread ${spread}°F is thin`); soft++; }
  }
  if (precipBlocked) {
    const nogoPop = lerp(68, 32, cal.precip);
    const softPop = lerp(42, 15, cal.precip);
    if ((raw.pop != null && raw.pop >= nogoPop) || /rain|storm|shower/i.test(raw.shortForecast)) {
      reasons.push(raw.pop != null ? `Precip ${raw.pop}%` : raw.shortForecast || "Wet");
      hard++;
    } else if (raw.pop != null && raw.pop >= softPop) {
      reasons.push(`Precip ${raw.pop}%`);
      soft++;
    }
  }
  if (wind != null && env.windMaxMph != null) {
    const hit = overLimit(wind, env.windMaxMph, cal.wind);
    if (hit === "hard") { reasons.push(`Wind ${Math.round(wind)} mph > ${env.windMaxMph}`); hard++; }
    else if (hit === "soft") { reasons.push(`Wind near limit`); soft++; }
  }
  if (fogged) {
    reasons.push(site.moistureTolerant ? "Fog/mist — confirm SSD/dry per PDS" : "Fog/mist — wipe dry & re-log dew point (NACE/SSPC)");
    soft++;
  }
  if (!shiftOk) {
    reasons.unshift(mits.includes("night_shift") ? "Outside night shift (19:00–06:00)" : "Outside dawn window");
    hard++;
  }

  let status: WindowStatus = "go";
  if (hard > 0) status = "nogo";
  else if (soft > 0) status = "caution";
  if (status === "go" && reasons.length === 0) {
    const extra = mits.length ? ` after ${mits.map((id) => mitigationById(id)?.label ?? id).join(", ")}` : "";
    reasons.push(`Inside PDS window${extra}`);
  }

  return {
    startIso: raw.startIso,
    hour: z.hour,
    weekday: z.weekday,
    dateLabel: z.dateLabel,
    dateKey: z.dateKey,
    status,
    reasons,
    tempF: raw.tempF,
    rh: raw.rh,
    dewpointF: raw.dewpointF,
    spreadF: spread,
    pop: raw.pop,
    windMph: raw.windMph,
    shortForecast: raw.shortForecast,
    substrateF,
    solarGainF: round1(Math.max(0, solarGain)),
  };
}

function bestRange(hours: HourWindow[]): string | null {
  if (!hours.length) return null;
  const preferGo = hours.some((h) => h.status === "go");
  const ok = (h: HourWindow) => (preferGo ? h.status === "go" : h.status === "go" || h.status === "caution");
  let bestStart = -1;
  let bestLen = 0;
  let i = 0;
  while (i < hours.length) {
    if (!ok(hours[i])) { i++; continue; }
    let j = i;
    while (j < hours.length && ok(hours[j])) j++;
    if (j - i > bestLen) { bestLen = j - i; bestStart = i; }
    i = j;
  }
  if (bestStart < 0) return null;
  if (bestLen >= 18) return "All day";
  const a = hours[bestStart];
  const b = hours[bestStart + bestLen - 1];
  const fmt = (h: number) => `${String(h).padStart(2, "0")}:00`;
  return `${fmt(a.hour)}–${fmt(Math.min(24, b.hour + 1))}`;
}

export function bundleDays(
  hours: HourWindow[],
  meta: Omit<ForecastBundle, "days" | "headline">,
  site: SiteCtx,
): ForecastBundle {
  const byDate = new Map<string, HourWindow[]>();
  for (const h of hours) {
    const list = byDate.get(h.dateKey) ?? [];
    list.push(h);
    byDate.set(h.dateKey, list);
  }
  const goNeed = Math.round(lerp(2, 5, site.calibration?.master ?? 0.55));
  const days: DayWindow[] = [];
  for (const [date, list] of byDate) {
    const goHours = list.filter((h) => h.status === "go").length;
    const cautionHours = list.filter((h) => h.status === "caution").length;
    const nogoHours = list.filter((h) => h.status === "nogo").length;
    let status: WindowStatus = "unknown";
    if (goHours >= goNeed) status = "go";
    else if (goHours > 0 || cautionHours >= goNeed) status = "caution";
    else if (list.some((h) => h.status !== "unknown")) status = "nogo";
    const reasonCount = new Map<string, number>();
    for (const h of list) {
      if (h.status === "nogo" || h.status === "caution") {
        const key = h.reasons[0] ?? "";
        if (key) reasonCount.set(key, (reasonCount.get(key) ?? 0) + 1);
      }
    }
    const limiting = [...reasonCount.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k]) => k);
    days.push({
      date,
      weekday: list[0]?.weekday ?? "",
      dateLabel: list[0]?.dateLabel ?? date,
      status,
      goHours,
      cautionHours,
      nogoHours,
      bestRange: bestRange(list),
      limiting,
      hours: list,
    });
  }
  days.sort((a, b) => a.date.localeCompare(b.date));
  const best = [...days].filter((d) => d.status === "go").sort((a, b) => b.goHours - a.goHours)[0];
  const mitLabel = site.mitigations.map((id) => mitigationById(id)?.label).filter(Boolean).join(" + ");
  const withMits = mitLabel ? ` with ${mitLabel}` : "";
  let headline = "Forecast loaded.";
  if (best?.bestRange) headline = `Best window${withMits}: ${best.weekday} ${best.dateLabel}  ${best.bestRange}  (${best.goHours} go hours)`;
  else headline = mitLabel ? `Still tight with ${mitLabel}. Add mitigation or hold.` : "No clean go-day in this forecast.";
  return { ...meta, days, headline };
}

export function rescoreForecast(forecast: ForecastBundle, env: Environmentals, site: SiteCtx): ForecastBundle {
  const hours = forecast.rawHours.map((h) => scoreHour(h, env, forecast.timezone, site));
  return bundleDays(hours, {
    zip: forecast.zip,
    city: forecast.city,
    state: forecast.state,
    timezone: forecast.timezone,
    source: forecast.source,
    rawHours: forecast.rawHours,
  }, site);
}

export async function loadForecast(zip: string, env: Environmentals, site: SiteCtx): Promise<ForecastBundle> {
  const geoRes = await fetch(`https://api.zippopotam.us/us/${zip}`);
  if (!geoRes.ok) throw new Error("ZIP not found. Use a 5-digit US ZIP.");
  const geo = await geoRes.json() as { places?: { "place name": string; "state abbreviation": string; latitude: string; longitude: string }[] };
  const place = geo.places?.[0];
  if (!place) throw new Error("ZIP not found.");
  const lat = Number(place.latitude);
  const lon = Number(place.longitude);
  const city = place["place name"];
  const state = place["state abbreviation"];

  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(lat));
  url.searchParams.set("longitude", String(lon));
  url.searchParams.set("hourly", "temperature_2m,relative_humidity_2m,dew_point_2m,precipitation_probability,wind_speed_10m,weather_code,cloud_cover");
  url.searchParams.set("temperature_unit", "fahrenheit");
  url.searchParams.set("wind_speed_unit", "mph");
  url.searchParams.set("timezone", "auto");
  url.searchParams.set("forecast_days", "7");
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error("Weather forecast unavailable.");
  const body = await res.json() as {
    timezone?: string;
    hourly?: {
      time: string[];
      temperature_2m: (number | null)[];
      relative_humidity_2m: (number | null)[];
      dew_point_2m: (number | null)[];
      precipitation_probability: (number | null)[];
      wind_speed_10m: (number | null)[];
      weather_code: (number | null)[];
      cloud_cover?: (number | null)[];
    };
  };
  const h = body.hourly;
  if (!h?.time?.length) throw new Error("Hourly forecast empty.");
  const wx = (code: number | null) => {
    if (code == null) return "";
    if (code >= 95) return "Thunderstorm";
    if (code >= 80) return "Showers";
    if (code >= 61) return "Rain";
    if (code >= 1) return "Clouds";
    return "Clear";
  };
  const rawHours: RawHour[] = h.time.map((time, i) => ({
    startIso: time.length === 16 ? `${time}:00` : time,
    tempF: h.temperature_2m[i] ?? null,
    rh: h.relative_humidity_2m[i] ?? null,
    dewpointF: h.dew_point_2m[i] ?? null,
    pop: h.precipitation_probability[i] ?? null,
    windMph: h.wind_speed_10m[i] ?? null,
    shortForecast: wx(h.weather_code[i] ?? null),
    cloudCover: h.cloud_cover?.[i] ?? null,
  }));
  const scored = rawHours.map((r) => scoreHour(r, env, body.timezone ?? "auto", site));
  return bundleDays(scored, {
    zip,
    city,
    state,
    timezone: body.timezone ?? "auto",
    source: "Open-Meteo (NOAA models)",
    rawHours,
  }, site);
}
