export type Confidence = "high" | "medium" | "low";

export type Environmentals = {
  ambientTempMinF: number | null;
  ambientTempMaxF: number | null;
  substrateTempMinF: number | null;
  substrateTempMaxF: number | null;
  relativeHumidityMax: number | null;
  dewPointSpreadMinF: number | null;
  precipitationAllowed: boolean;
  windMaxMph: number | null;
  notes: string;
};

export type FieldCardData = {
  id: string;
  product: {
    name: string;
    manufacturer: string;
    productType: string;
    mixRatio: string;
    revision: string;
  };
  storage: { temperatureRange: string; conditions: string[] };
  shelfLife: { unopened: string; mixedPotLife: string };
  credentials: { required: string[] };
  surfacePrep: {
    substrates: string[];
    methods: string[];
    profile: string;
    cleanliness: string;
  };
  environmentals: Environmentals;
  mixing: { ratio: string; potLife: string; inductionTime: string };
  installation: { methods: string[]; filmThickness: string; coverage: string };
  holdPoints: { step: number; name: string; criteria: string }[];
  inspection: { methods: string[] };
  cure: { touch: string; recoatMin: string; fullCure: string };
  safety: { ppe: string[] };
};

export type WindowStatus = "go" | "caution" | "nogo" | "unknown";

export type HourWindow = {
  startIso: string;
  hour: number;
  weekday: string;
  dateLabel: string;
  dateKey: string;
  status: WindowStatus;
  reasons: string[];
  tempF: number | null;
  rh: number | null;
  dewpointF: number | null;
  spreadF: number | null;
  pop: number | null;
  windMph: number | null;
  shortForecast: string;
  substrateF?: number | null;
  solarGainF?: number | null;
};

export type DayWindow = {
  date: string;
  weekday: string;
  dateLabel: string;
  status: WindowStatus;
  goHours: number;
  cautionHours: number;
  nogoHours: number;
  bestRange: string | null;
  limiting: string[];
  hours: HourWindow[];
};

export type ForecastBundle = {
  zip: string;
  city: string;
  state: string;
  timezone: string;
  source: string;
  days: DayWindow[];
  headline: string;
  rawHours: RawHour[];
};

export type RawHour = {
  startIso: string;
  tempF: number | null;
  rh: number | null;
  dewpointF: number | null;
  pop: number | null;
  windMph: number | null;
  shortForecast: string;
  cloudCover?: number | null;
};

export type SubstrateId =
  | "bare_steel"
  | "mill_scale"
  | "concrete"
  | "concrete_light_paint"
  | "concrete_dark_paint"
  | "wood"
  | "glass"
  | "aluminum"
  | "galvanized";

export type MitigationId =
  | "canopy"
  | "fog_mist"
  | "night_shift"
  | "light_tent"
  | "dark_tent"
  | "dehumidify_tent"
  | "humidity_tent"
  | "climate_tent"
  | "early_start"
  | "heaters"
  | "preheat"
  | "windscreen";

export type Calibration = {
  master: number;
  solar: number;
  thermal: number;
  moisture: number;
  precip: number;
  wind: number;
  linked: boolean;
};

export const DEFAULT_CALIBRATION: Calibration = {
  master: 0.55,
  solar: 0.55,
  thermal: 0.55,
  moisture: 0.55,
  precip: 0.55,
  wind: 0.55,
  linked: true,
};

export const STEP_RAIL = [
  { n: "01", id: "store", label: "Store" },
  { n: "02", id: "creds", label: "Qualify" },
  { n: "03", id: "prep", label: "Prep" },
  { n: "04", id: "ambnt", label: "Ambient" },
  { n: "05", id: "mix", label: "Mix" },
  { n: "06", id: "apply", label: "Apply" },
  { n: "07", id: "hold", label: "Hold" },
  { n: "08", id: "insp", label: "Inspect" },
  { n: "09", id: "cure", label: "Cure" },
  { n: "10", id: "safe", label: "Safety" },
];
