import type { MitigationId, SubstrateId } from "./types";

export type Limiter = "heat" | "solar" | "cold" | "rh" | "dew" | "rain" | "wind";

export const SUBSTRATES: {
  id: SubstrateId;
  label: string;
  peakGainF: number;
  metal: boolean;
  note: string;
}[] = [
  { id: "bare_steel", label: "Bare steel", peakGainF: 46, metal: true, note: "Blasted steel runs 40–55°F above air in full sun." },
  { id: "mill_scale", label: "Mill scale steel", peakGainF: 54, metal: true, note: "Blue-black mill scale soaks solar harder than bare steel." },
  { id: "concrete", label: "Concrete", peakGainF: 22, metal: false, note: "Gray mass lags air and holds afternoon heat." },
  { id: "concrete_light_paint", label: "Light painted concrete", peakGainF: 10, metal: false, note: "High albedo — stays closer to air temp." },
  { id: "concrete_dark_paint", label: "Dark painted concrete", peakGainF: 40, metal: false, note: "Dark film on mass runs like hot steel." },
  { id: "wood", label: "Wood", peakGainF: 16, metal: false, note: "Lower peak than metal; slow to dump heat." },
  { id: "glass", label: "Glass", peakGainF: 12, metal: false, note: "Tracks air more than steel; watch dew on the lite." },
  { id: "aluminum", label: "Aluminum", peakGainF: 18, metal: true, note: "Light metal heats fast but cooler than carbon steel." },
  { id: "galvanized", label: "Galvanized steel", peakGainF: 26, metal: true, note: "Zinc is more reflective; still above air in sun." },
];

export const MITIGATIONS: {
  id: MitigationId;
  label: string;
  summary: string;
  citation: string;
  helps: Limiter[];
  metalOnly?: boolean;
  conflicts?: MitigationId[];
}[] = [
  { id: "canopy", label: "Canopy / sunshade", summary: "Open shade over the workface. Cuts solar gain; air stays ambient.", citation: "AMPP / NACE · ACI 305R", helps: ["solar", "heat"] },
  { id: "fog_mist", label: "Water fog / mist cooldown", summary: "Evaporative cool-down. Metals: mist, wipe dry, re-log dew point.", citation: "NACE / SSPC · ACI 305R", helps: ["heat", "solar"] },
  { id: "night_shift", label: "Night shift", summary: "Work 19:00–06:00 only. Solar gain drops to zero.", citation: "AMPP · ACI 305R", helps: ["solar", "heat"], conflicts: ["early_start"] },
  { id: "light_tent", label: "Light-colored tent", summary: "Reflective enclosure. Kills rain and most sun without cooking the interior.", citation: "SSPC / AMPP · ACI 305R", helps: ["solar", "heat", "rain", "wind"], conflicts: ["dark_tent"] },
  { id: "dark_tent", label: "Dark-colored tent", summary: "Absorptive enclosure — use for cold weather, not hot steel days.", citation: "ACI 306R", helps: ["cold", "rain"], conflicts: ["light_tent"] },
  { id: "dehumidify_tent", label: "Dehumidify tent", summary: "Enclosed work with mechanical dehumidification.", citation: "AMPP / NACE / SSPC", helps: ["rh", "dew", "rain"] },
  { id: "humidity_tent", label: "Humidity / moist-cure tent", summary: "Holds moisture for cementitious work. Wrong for dry-face coatings.", citation: "ACI 308R", helps: ["wind"] },
  { id: "climate_tent", label: "Climate-control tent", summary: "Conditioned enclosure — temperature, humidity, and weather.", citation: "AMPP / NACE / SSPC · ACI", helps: ["heat", "cold", "rh", "dew", "rain", "solar", "wind"] },
  { id: "early_start", label: "Dawn / AM only", summary: "Work 05:00–10:00 before peak solar.", citation: "AMPP · ACI 305R", helps: ["solar", "heat"], conflicts: ["night_shift"] },
  { id: "heaters", label: "Indirect heaters", summary: "Raises air and substrate for a cold floor.", citation: "ACI 306R · AMPP", helps: ["cold"] },
  { id: "preheat", label: "Preheat substrate", summary: "Blankets or induction on metal.", citation: "NACE / AMPP", helps: ["cold"], metalOnly: true },
  { id: "windscreen", label: "Wind screens", summary: "Cuts effective wind for spray. Does not cool the workface.", citation: "SSPC · ACI", helps: ["wind"] },
];

export function substrateById(id: SubstrateId) {
  return SUBSTRATES.find((s) => s.id === id) ?? SUBSTRATES[0];
}

export function mitigationById(id: MitigationId) {
  return MITIGATIONS.find((m) => m.id === id);
}

export function inferSubstrate(labels: string[]): SubstrateId {
  for (const label of labels) {
    const t = label.toLowerCase();
    if (/mill[\s-]?scale/.test(t)) return "mill_scale";
    if (/galvaniz/.test(t)) return "galvanized";
    if (/aluminium|aluminum/.test(t)) return "aluminum";
    if (/\bglass\b/.test(t)) return "glass";
    if (/wood/.test(t)) return "wood";
    if (/concrete/.test(t) && /light|white/.test(t)) return "concrete_light_paint";
    if (/concrete/.test(t) && /dark|black|paint/.test(t)) return "concrete_dark_paint";
    if (/concrete/.test(t)) return "concrete";
    if (/steel|carbon|ferrous|bare/.test(t)) return "bare_steel";
  }
  return "bare_steel";
}

export function skyFactor(shortForecast: string, cloudCover?: number | null) {
  if (cloudCover != null && Number.isFinite(cloudCover)) return Math.max(0.05, 1 - cloudCover / 110);
  const t = shortForecast.toLowerCase();
  if (/thunder|storm|rain|shower|snow/.test(t)) return 0.08;
  if (/mostly (sunny|clear)/.test(t)) return 0.82;
  if (/\b(sunny|clear)\b/.test(t)) return 1;
  if (/partly/.test(t)) return 0.55;
  if (/mostly cloudy/.test(t)) return 0.28;
  if (/cloud|overcast/.test(t)) return 0.18;
  return 0.5;
}

export function solarEnvelope(hour: number) {
  if (hour < 6 || hour >= 19) return 0;
  const t = (hour + 0.5 - 6) / 13;
  return Math.sin(Math.PI * t);
}

export function inShift(hour: number, mitigations: MitigationId[]) {
  if (mitigations.includes("night_shift")) return hour >= 19 || hour < 6;
  if (mitigations.includes("early_start")) return hour >= 5 && hour < 10;
  return true;
}

export function peakExample(substrate: SubstrateId, airF = 80) {
  const sub = substrateById(substrate);
  const gain = Math.round(sub.peakGainF * solarEnvelope(13));
  return { airF, substrateF: airF + gain, gain, note: sub.note };
}
