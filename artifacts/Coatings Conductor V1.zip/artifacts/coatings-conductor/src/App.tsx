import { useEffect, useMemo, useState } from "react";
import {
  CloudSun,
  Download,
  Loader2,
  MapPin,
  Printer,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { MITIGATIONS, peakExample, substrateById, SUBSTRATES } from "./lib/mitigations";
import { loadForecast, rescoreForecast, type SiteCtx } from "./lib/score";
import { SAMPLES, SAMPLE_TEXT } from "./lib/samples";
import type {
  Calibration,
  Environmentals,
  FieldCardData,
  ForecastBundle,
  HourWindow,
  MitigationId,
  SubstrateId,
  WindowStatus,
} from "./lib/types";
import { DEFAULT_CALIBRATION, STEP_RAIL } from "./lib/types";

function cn(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

function statusFill(s: WindowStatus) {
  if (s === "go") return "bg-go";
  if (s === "caution") return "bg-caution";
  if (s === "nogo") return "bg-nogo";
  return "bg-subtle";
}

function statusBadge(s: WindowStatus) {
  const base = "inline-flex items-center rounded-sm px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide";
  if (s === "go") return cn(base, "bg-go/25 text-go-soft");
  if (s === "caution") return cn(base, "bg-caution/25 text-caution-soft");
  if (s === "nogo") return cn(base, "bg-nogo/25 text-nogo-soft");
  return cn(base, "bg-surface-2 text-muted");
}

function HourStrip({ hours, night }: { hours: HourWindow[]; night?: boolean }) {
  const usable = night ? hours : hours.filter((h) => h.hour >= 5 && h.hour <= 20);
  const [tip, setTip] = useState<HourWindow | null>(null);
  return (
    <div>
      <div className="flex h-7 overflow-hidden rounded-sm">
        {usable.map((h) => (
          <button
            key={h.startIso}
            type="button"
            className={cn("hour-cell min-w-0 flex-1", statusFill(h.status))}
            title={`${String(h.hour).padStart(2, "0")}:00 · ${h.status} · ${h.reasons[0] ?? ""}`}
            onMouseEnter={() => setTip(h)}
            onMouseLeave={() => setTip(null)}
          />
        ))}
      </div>
      <div className="mt-1 flex justify-between font-mono text-[10px] text-muted">
        <span>{night ? "00" : "05"}</span>
        <span>12</span>
        <span>{night ? "23" : "20"}</span>
      </div>
      {tip ? (
        <p className="mt-1 font-mono text-[11px] text-fg">
          {String(tip.hour).padStart(2, "0")}:00 · air {tip.tempF ?? "—"}°
          {tip.substrateF != null ? ` · sub ${tip.substrateF}°` : ""} · {tip.reasons[0]}
        </p>
      ) : null}
    </div>
  );
}

function FieldCardView({ card }: { card: FieldCardData }) {
  const env = card.environmentals;
  const blocks: { id: string; title: string; body: import("react").ReactNode }[] = [
    {
      id: "store",
      title: "01 · Store",
      body: (
        <>
          <p className="font-mono text-sm">{card.storage.temperatureRange}</p>
          <p className="mt-1 text-xs text-ink-muted">{card.storage.conditions.join(" · ")}</p>
          <p className="mt-2 text-xs">Shelf: {card.shelfLife.unopened} · Pot life: {card.shelfLife.mixedPotLife}</p>
        </>
      ),
    },
    {
      id: "creds",
      title: "02 · Qualify",
      body: <p className="text-xs leading-relaxed">{card.credentials.required.join(" · ")}</p>,
    },
    {
      id: "prep",
      title: "03 · Prep",
      body: (
        <>
          <p className="text-xs"><span className="font-medium">Substrates:</span> {card.surfacePrep.substrates.join(", ")}</p>
          <p className="mt-1 text-xs"><span className="font-medium">Methods:</span> {card.surfacePrep.methods.join("; ")}</p>
          <p className="mt-1 text-xs">Profile {card.surfacePrep.profile} · {card.surfacePrep.cleanliness}</p>
        </>
      ),
    },
    {
      id: "ambnt",
      title: "04 · Ambient",
      body: (
        <div className="grid grid-cols-2 gap-2 font-mono text-xs">
          <span>Air {env.ambientTempMinF ?? "—"}–{env.ambientTempMaxF ?? "—"}°F</span>
          <span>Steel {env.substrateTempMinF ?? "—"}–{env.substrateTempMaxF ?? "—"}°F</span>
          <span>Dew ≥{env.dewPointSpreadMinF ?? "—"}°F</span>
          <span>{env.precipitationAllowed ? "Precip OK" : "Dry only"}</span>
          {env.windMaxMph != null ? <span>Wind ≤{env.windMaxMph} mph</span> : null}
          {env.notes ? <p className="col-span-2 font-sans text-[11px] text-ink-muted">{env.notes}</p> : null}
        </div>
      ),
    },
    {
      id: "mix",
      title: "05 · Mix",
      body: (
        <p className="text-xs">
          {card.mixing.ratio} · Pot life {card.mixing.potLife}
          {card.mixing.inductionTime !== "None" && card.mixing.inductionTime !== "N/A" ? ` · Induction ${card.mixing.inductionTime}` : ""}
        </p>
      ),
    },
    {
      id: "apply",
      title: "06 · Apply",
      body: (
        <p className="text-xs">
          {card.installation.methods.join(" · ")} · {card.installation.filmThickness} · {card.installation.coverage}
        </p>
      ),
    },
    {
      id: "hold",
      title: "07 · Hold",
      body: (
        <ol className="space-y-1 text-xs">
          {card.holdPoints.map((h) => (
            <li key={h.step}>
              <span className="font-mono text-rail">{String(h.step).padStart(2, "0")}</span> {h.name} — {h.criteria}
            </li>
          ))}
        </ol>
      ),
    },
    {
      id: "insp",
      title: "08 · Inspect",
      body: <p className="text-xs">{card.inspection.methods.join(" · ")}</p>,
    },
    {
      id: "cure",
      title: "09 · Cure",
      body: (
        <p className="text-xs">
          Touch {card.cure.touch} · Recoat {card.cure.recoatMin} · Full {card.cure.fullCure}
        </p>
      ),
    },
    {
      id: "safe",
      title: "10 · Safety",
      body: <p className="text-xs">{card.safety.ppe.join(" · ")}</p>,
    },
  ];

  return (
    <article id="field-card-print" className="paper-card rise-in overflow-hidden rounded-lg">
      <div className="caution-stripe h-1.5 w-full" />
      <div className="flex gap-0">
        <div className="hidden w-10 shrink-0 flex-col items-center gap-1 bg-rail py-4 sm:flex">
          {STEP_RAIL.map((s) => (
            <span key={s.n} className="font-mono text-[9px] font-bold text-paper/80" title={s.label}>
              {s.n}
            </span>
          ))}
        </div>
        <div className="min-w-0 flex-1 p-4 sm:p-5">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-rail">
            Coatings Conductor · Field card
          </p>
          <h2 className="mt-1 text-xl font-semibold tracking-tight text-ink sm:text-2xl">{card.product.name}</h2>
          <p className="mt-0.5 text-xs text-ink-muted">
            {card.product.manufacturer} · {card.product.productType}
          </p>
          <div className="mt-4 space-y-3 border-t border-black/10 pt-3">
            {blocks.map((b) => (
              <section key={b.id}>
                <h3 className="text-[10px] font-bold uppercase tracking-wide text-rail">{b.title}</h3>
                <div className="mt-1 text-ink">{b.body}</div>
              </section>
            ))}
          </div>
        </div>
      </div>
    </article>
  );
}

async function downloadPdf(card: FieldCardData, forecast: ForecastBundle | null, site: SiteCtx) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const margin = 40;
  let y = 48;
  doc.setFillColor(239, 232, 216);
  doc.rect(0, 0, 612, 792, "F");
  doc.setFillColor(196, 69, 10);
  doc.rect(0, 0, 14, 792, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(196, 69, 10);
  doc.text("COATINGS CONDUCTOR  ·  FIELD CARD", margin, y);
  y += 22;
  doc.setFontSize(16);
  doc.setTextColor(30, 33, 36);
  doc.text(card.product.name, margin, y);
  y += 16;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(90, 95, 102);
  doc.text(`${card.product.manufacturer}  ·  ${card.product.productType}`, margin, y);
  y += 20;
  const lines = [
    `Store: ${card.storage.temperatureRange}`,
    `Shelf / pot: ${card.shelfLife.unopened} / ${card.shelfLife.mixedPotLife}`,
    `Prep: ${card.surfacePrep.methods.join("; ")}`,
    `Ambient: air ${card.environmentals.ambientTempMinF}–${card.environmentals.ambientTempMaxF}°F · steel ${card.environmentals.substrateTempMinF}–${card.environmentals.substrateTempMaxF}°F · dew ≥${card.environmentals.dewPointSpreadMinF}°F`,
    `Mix: ${card.mixing.ratio} · ${card.mixing.potLife}`,
    `Apply: ${card.installation.methods.join(", ")} · ${card.installation.filmThickness}`,
    `Substrate (this job): ${substrateById(site.substrate).label}`,
    site.mitigations.length
      ? `Mitigations: ${site.mitigations.map((id) => MITIGATIONS.find((m) => m.id === id)?.label ?? id).join(", ")}`
      : "Mitigations: none",
  ];
  doc.setTextColor(30, 33, 36);
  doc.setFontSize(10);
  for (const line of lines) {
    const wrapped = doc.splitTextToSize(line, 520) as string[];
    doc.text(wrapped, margin, y);
    y += wrapped.length * 13 + 4;
  }
  if (forecast) {
    y += 10;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(196, 69, 10);
    doc.text("APPLICATION WINDOWS", margin, y);
    y += 14;
    doc.setFont("helvetica", "normal");
    doc.setTextColor(30, 33, 36);
    const head = doc.splitTextToSize(forecast.headline, 520) as string[];
    doc.text(head, margin, y);
    y += head.length * 12 + 8;
    for (const d of forecast.days.slice(0, 7)) {
      doc.text(
        `${d.weekday} ${d.dateLabel}  ${d.status.toUpperCase()}  ${d.bestRange ?? "—"}  (${d.goHours}h go)`,
        margin,
        y,
      );
      y += 12;
    }
  }
  doc.save(`${card.product.name.replace(/\s+/g, "-").toLowerCase()}-field-card.pdf`);
}

export default function App() {
  const [text, setText] = useState("");
  const [card, setCard] = useState<FieldCardData | null>(null);
  const [zip, setZip] = useState(() => localStorage.getItem("cc.zip") ?? "22202");
  const [forecast, setForecast] = useState<ForecastBundle | null>(null);
  const [wxLoading, setWxLoading] = useState(false);
  const [wxError, setWxError] = useState<string | null>(null);
  const [substrate, setSubstrate] = useState<SubstrateId>("bare_steel");
  const [mitigations, setMitigations] = useState<MitigationId[]>([]);
  const [calibration, setCalibration] = useState<Calibration>(DEFAULT_CALIBRATION);
  const [downloading, setDownloading] = useState(false);

  const site: SiteCtx = useMemo(
    () => ({ substrate, mitigations, calibration, moistureTolerant: /moisture-tolerant/i.test(card?.product.productType ?? "") }),
    [substrate, mitigations, calibration, card],
  );

  const scored = useMemo(() => {
    if (!forecast || !card) return forecast;
    return rescoreForecast(forecast, card.environmentals, site);
  }, [forecast, card, site]);

  const example = peakExample(substrate, 80);
  const night = mitigations.includes("night_shift");
  const sub = substrateById(substrate);

  function applySample(key: string) {
    const sample = SAMPLES.find((s) => s.key === key);
    if (!sample) return;
    const next = { ...sample.card, id: crypto.randomUUID() };
    setText(SAMPLE_TEXT[key] ?? "");
    setCard(next);
    setSubstrate(
      next.surfacePrep.substrates.some((s) => /steel/i.test(s)) ? "bare_steel" : "concrete",
    );
    setForecast(null);
    toast.success("Field card on the stand.");
    if (zip.length === 5) void runForecast(next, zip);
  }

  async function runForecast(active: FieldCardData | null = card, nextZip = zip) {
    if (!active) {
      toast.error("Load a product card first.");
      return;
    }
    if (nextZip.length !== 5) {
      toast.error("Enter a 5-digit US ZIP.");
      return;
    }
    localStorage.setItem("cc.zip", nextZip);
    setWxLoading(true);
    setWxError(null);
    try {
      const result = await loadForecast(nextZip, active.environmentals, {
        substrate,
        mitigations,
        calibration,
      });
      setForecast(result);
    } catch (err) {
      setWxError(err instanceof Error ? err.message : "Forecast failed");
    } finally {
      setWxLoading(false);
    }
  }

  function addMitigation(id: MitigationId) {
    const def = MITIGATIONS.find((m) => m.id === id);
    const next = mitigations.filter((m) => !def?.conflicts?.includes(m) && m !== id);
    next.push(id);
    setMitigations(next);
  }

  function updateEnv(patch: Partial<Environmentals>) {
    if (!card) return;
    setCard({ ...card, environmentals: { ...card.environmentals, ...patch } });
  }

  useEffect(() => {
    if (!card) return;
    const el = document.getElementById("field-card-print");
    if (el && window.innerWidth < 1024) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [card?.id]);

  return (
    <div className="min-h-screen text-fg">
      <header className="no-print border-b border-border/80 bg-surface/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <img src="/mascot.png" alt="Coatings Conductor mascot" className="size-12 rounded-md object-cover object-top shadow-[0_0_0_1px_rgba(255,183,3,0.35)]" />
            <div>
              <p className="text-sm font-bold tracking-tight text-fg">Coatings Conductor</p>
              <p className="text-[11px] text-muted">PDS field card · weather windows · mitigations</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border bg-surface-2 px-3 text-xs font-medium text-fg disabled:opacity-40"
              disabled={!card}
              onClick={() => window.print()}
            >
              <Printer className="size-3.5" /> Print
            </button>
            <button
              type="button"
              className="inline-flex h-9 items-center gap-1.5 rounded-md bg-accent px-3 text-xs font-semibold text-white disabled:opacity-40"
              disabled={!card || downloading}
              onClick={async () => {
                if (!card) return;
                setDownloading(true);
                try {
                  await downloadPdf(card, scored, site);
                  toast.success("PDF downloaded.");
                } catch (e) {
                  toast.error(e instanceof Error ? e.message : "PDF failed");
                } finally {
                  setDownloading(false);
                }
              }}
            >
              <Download className="size-3.5" /> PDF
            </button>
          </div>
        </div>
        <div className="caution-stripe h-1 w-full opacity-90" />
      </header>

      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1.05fr)_minmax(20rem,0.95fr)]">
        <div className="no-print space-y-6 lg:col-start-1 lg:row-start-1">
          <section className="rise-in">
            <div className="flex items-start gap-4">
              <img
                src="/mascot.png"
                alt=""
                className="hidden size-20 shrink-0 rounded-lg object-cover object-top shadow-[0_0_0_1px_rgba(232,93,4,0.4)] sm:block"
              />
              <div>
                <h1 className="max-w-xl text-3xl font-bold tracking-tight text-fg sm:text-4xl">
                  Call the coating window.
                </h1>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted sm:text-base">
                  Progression field card from the PDS — storage through safety — then NOAA windows scored against the
                  real substrate. Steel in the sun is not air at the ZIP.
                </p>
              </div>
            </div>
          </section>

          <section className="rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgba(255,255,255,0.06)] sm:p-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-accent-2">Product intake</p>
            <p className="mt-1 text-sm text-muted">Load a sample or paste PDS notes. Build the progression card, then score the job ZIP.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {SAMPLES.map((s) => (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => applySample(s.key)}
                  className="rounded-md bg-surface-2 px-3 py-2 text-left text-xs shadow-[0_0_0_1px_rgba(255,255,255,0.06)] transition hover:shadow-[0_0_0_1px_rgba(232,93,4,0.5)]"
                >
                  <span className="font-medium text-fg">{s.label}</span>
                  <span className="mt-0.5 block text-[11px] text-muted">{s.blurb}</span>
                </button>
              ))}
            </div>
            <textarea
              className="mt-3 min-h-28 w-full rounded-md bg-surface-2 p-3 text-sm text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)] outline-none focus:shadow-[0_0_0_1px_rgba(232,93,4,0.6)]"
              placeholder="Paste PDS ambient, prep, and hold-point language…"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <button
              type="button"
              className="mt-3 inline-flex h-10 items-center rounded-md bg-accent px-4 text-sm font-semibold text-white disabled:opacity-40"
              disabled={!text.trim()}
              onClick={() => {
                const match = SAMPLES.find((s) => text.toLowerCase().includes(s.card.product.name.split(" ")[0].toLowerCase()));
                if (match) applySample(match.key);
                else {
                  applySample("macropoxy");
                  toast.message("Using Macropoxy sample structure — replace with full extract in production.");
                }
              }}
            >
              Build field card
            </button>
          </section>
        </div>

        <div className="min-w-0 lg:col-start-1 lg:row-start-2">
          {card ? (
            <FieldCardView card={card} />
          ) : (
            <div className="rounded-xl border border-dashed border-border bg-surface/50 px-4 py-16 text-center">
              <img src="/mascot.png" alt="" className="mx-auto size-16 rounded-md object-cover object-top opacity-80" />
              <p className="mt-3 text-sm text-muted">Whistle ready. Load a product to put the card on the stand.</p>
            </div>
          )}
        </div>

        <div className="no-print space-y-4 lg:col-start-2 lg:row-start-1 lg:row-span-2">
          <aside className="rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgba(255,255,255,0.06)] sm:p-5">
            <div className="flex items-center gap-2 text-accent-2">
              <CloudSun className="size-4" />
              <p className="text-xs font-semibold uppercase tracking-wide">Application windows</p>
            </div>
            <p className="mt-2 text-sm text-muted">
              Score air, estimated substrate in sun, RH, dew spread, wind, and rain. Pick substrate and mitigations you will field.
            </p>
            <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
              <div className="min-w-0 flex-1">
                <label className="text-xs font-medium text-muted" htmlFor="zip">Job-site ZIP</label>
                <div className="relative mt-1.5">
                  <MapPin className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
                  <input
                    id="zip"
                    inputMode="numeric"
                    maxLength={5}
                    className="h-11 w-full rounded-md bg-surface-2 pl-9 font-mono tracking-widest text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)] outline-none focus:shadow-[0_0_0_1px_rgba(232,93,4,0.55)]"
                    value={zip}
                    onChange={(e) => setZip(e.target.value.replace(/\D/g, "").slice(0, 5))}
                    onKeyDown={(e) => e.key === "Enter" && void runForecast()}
                    placeholder="22202"
                  />
                </div>
              </div>
              <button
                type="button"
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-surface-2 px-4 text-sm font-medium text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)] disabled:opacity-40"
                disabled={!card || wxLoading || zip.length !== 5}
                onClick={() => void runForecast()}
              >
                {wxLoading ? <Loader2 className="size-4 animate-spin" /> : null}
                Load windows
              </button>
            </div>
            {wxError ? <p className="mt-2 text-sm text-nogo">{wxError}</p> : null}

            <div className="mt-5 border-t border-border pt-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted">Substrate</p>
              <select
                className="mt-2 h-11 w-full rounded-md bg-surface-2 px-3 text-sm text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"
                value={substrate}
                onChange={(e) => setSubstrate(e.target.value as SubstrateId)}
              >
                {SUBSTRATES.map((s) => (
                  <option key={s.id} value={s.id}>{s.label}</option>
                ))}
              </select>
              <p className="mt-2 text-xs leading-relaxed text-muted">
                {sub.note} Sunny {example.airF}°F afternoon estimates about{" "}
                <span className="font-mono text-fg">{example.substrateF}°F</span>
                {example.gain ? ` (+${example.gain}° solar)` : ""}.
              </p>
            </div>

            <div className="mt-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted">Mitigation</p>
              <select
                className="mt-2 h-11 w-full rounded-md bg-surface-2 px-3 text-sm text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"
                value=""
                onChange={(e) => {
                  const id = e.target.value as MitigationId;
                  if (id) addMitigation(id);
                }}
              >
                <option value="">Add a mitigation…</option>
                {MITIGATIONS.filter((m) => !(m.metalOnly && !sub.metal)).map((m) => (
                  <option key={m.id} value={m.id} disabled={mitigations.includes(m.id)}>
                    {m.label}{mitigations.includes(m.id) ? " · on" : ""}
                  </option>
                ))}
              </select>
              {mitigations.length ? (
                <ul className="mt-2 flex flex-wrap gap-2">
                  {mitigations.map((id) => {
                    const m = MITIGATIONS.find((x) => x.id === id);
                    return (
                      <li key={id}>
                        <button
                          type="button"
                          className="inline-flex h-8 items-center gap-1 rounded-md bg-go/20 px-2.5 text-xs font-medium text-go-soft shadow-[0_0_0_1px_rgba(61,122,86,0.5)]"
                          onClick={() => setMitigations(mitigations.filter((x) => x !== id))}
                        >
                          {m?.label ?? id}
                          <X className="size-3" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="mt-2 text-xs text-muted">None — unmitigated field conditions.</p>
              )}
            </div>

            {card ? (
              <div className="mt-5 border-t border-border pt-4">
                <p className="text-xs font-medium uppercase tracking-wide text-muted">Window limits</p>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {(
                    [
                      ["Air min", "ambientTempMinF"],
                      ["Air max", "ambientTempMaxF"],
                      ["Sub max", "substrateTempMaxF"],
                      ["Dew spread", "dewPointSpreadMinF"],
                    ] as const
                  ).map(([label, key]) => (
                    <label key={key} className="block">
                      <span className="text-[10px] text-muted">{label}</span>
                      <input
                        className="mt-1 h-9 w-full rounded-md bg-surface-2 px-2 font-mono text-sm text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"
                        inputMode="decimal"
                        value={card.environmentals[key] ?? ""}
                        onChange={(e) => {
                          const n = e.target.value === "" ? null : Number(e.target.value);
                          updateEnv({ [key]: n != null && Number.isFinite(n) ? n : null });
                        }}
                      />
                    </label>
                  ))}
                </div>
              </div>
            ) : null}

            <div className="mt-5 border-t border-border pt-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted">Call tightness</p>
              <p className="mt-1 text-xs text-muted">
                Field judgment ← → Spec-hard. Opens edge no-gos when the model over-calls steel heat.
              </p>
              <input
                type="range"
                min={0}
                max={100}
                className="mt-2 w-full accent-accent"
                value={Math.round(calibration.master * 100)}
                onChange={(e) => {
                  const n = Number(e.target.value) / 100;
                  setCalibration({ ...calibration, master: n, solar: n, thermal: n, moisture: n, precip: n, wind: n });
                }}
              />
              <p className="mt-1 font-mono text-[11px] text-accent-2">
                {calibration.master < 0.35 ? "Open — field judgment" : calibration.master > 0.7 ? "Spec-hard" : "Balanced"}
              </p>
            </div>
          </aside>

          {scored ? (
            <div className="rise-in space-y-3">
              <div className="rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgba(255,255,255,0.06)]">
                <p className="text-sm font-medium leading-snug text-fg">{scored.headline}</p>
                <p className="mt-1 text-xs text-muted">
                  {scored.city}, {scored.state} · {scored.source} · {sub.label}
                </p>
                <p className="mt-2 text-xs text-muted">
                  Model only — measure air, substrate, RH, and dew at the workface before you mix.
                </p>
                <div className="mt-2 flex flex-wrap gap-3 text-[11px] text-muted">
                  <span className="inline-flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-go" /> Go</span>
                  <span className="inline-flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-caution" /> Caution</span>
                  <span className="inline-flex items-center gap-1.5"><i className="size-2.5 rounded-sm bg-nogo" /> No-go</span>
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {scored.days.map((d) => (
                  <article key={d.date} className="rounded-lg bg-surface-2 p-3 shadow-[0_0_0_1px_rgba(255,255,255,0.05)]">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-[10px] font-medium uppercase tracking-wide text-muted">{d.weekday}</p>
                        <p className="font-mono text-sm text-fg">{d.dateLabel}</p>
                      </div>
                      <span className={statusBadge(d.status)}>{d.status}</span>
                    </div>
                    <p className="mt-2 font-mono text-sm text-fg">{d.bestRange ?? "No window"}</p>
                    <p className="mt-0.5 text-[11px] text-muted">{d.goHours}h go · {d.cautionHours}h caution</p>
                    {d.limiting[0] ? <p className="mt-1 line-clamp-2 text-[11px] text-muted">{d.limiting[0]}</p> : null}
                    <div className="mt-3">
                      <HourStrip hours={d.hours} night={night} />
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ) : (
            <div className="rounded-xl bg-surface px-4 py-10 text-center shadow-[0_0_0_1px_rgba(255,255,255,0.06)]">
              <p className="text-sm text-muted">Build a card, load a ZIP. Mitigations reopen days the sun would kill.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
